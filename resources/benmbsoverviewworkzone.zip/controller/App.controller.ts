import Controller from "sap/ui/core/mvc/Controller";

/**
 * @namespace be.nmbs.overviewworkzone.controller
 */
export default class App extends Controller {

    /*eslint-disable @typescript-eslint/no-empty-function*/
    public onInit(): void {

    }
}